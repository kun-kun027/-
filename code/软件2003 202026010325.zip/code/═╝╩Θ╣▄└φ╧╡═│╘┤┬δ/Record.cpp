#include "Record.h"
using namespace std;
void Record::Sethistory(string a,string b,string c,string d)
{
	Bookname=a;
	ISBN=b;
	Authorname=c;
	Dividename=d;
}
