#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H
#include <bits/stdc++.h>
using namespace std;
class Administrator
{
private:
	string account;
	string password;
public:
	Administrator()
	{
		account="crush_H78z";
		password="crush_H78z";
	}
};

#endif
